sudo apt-get install texlive-latex-base texlive-latex-extra texlive-latex-recommended texlive-science
sudo apt-get install xzdec
sudo apt-get install perl-tk
tlmgr init-usertree
tlmgr update --all
